

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="card border-0 shadow-sm">
        
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("users-create")): ?>
                <a href="<?php echo e(route("infos.create")); ?>" class="btn btn-success rounded-pill mb-3">Create info</a>
            <?php endif; ?>
            
            <h4 class="card-title">
                Infos <small class="text-muted">(<?php echo e(count($infos)); ?>)</small>
            </h4>
            <table class="table table-striped">
                <tr>
                    <th>Title</th>
                    <th>Categories</th>
                    <th>Mode</th>
                    <th>File</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($info->title); ?></td>
                        <td>
                            <?php $__currentLoopData = $info->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h5><span class="badge badge-secondary"><?php echo e($category->name); ?></span></h5>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($info->file_mode); ?></td>
                        <td>
                            <?php if($info->file_mode == "image"): ?>
                                <?php if($info->file_path): ?>
                                    <img src="<?php echo e($info->file_path); ?>" class="img-fluid" style="max-width: 100px;">
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($info->file_path): ?>
                                    <iframe width="200" src="https://www.youtube.com/embed/<?php echo e($info->file_path); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                                    </iframe> 
                                <?php endif; ?>
                            <?php endif; ?>    
                        </td>
                        <td><?php echo e($info->created_at); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("infos-list")): ?>
                                <a class="btn btn-info" href="<?php echo e(route("infos.show", $info->id)); ?>">Show</a>
                            <?php endif; ?> 
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("infos-edit")): ?>
                                <a class="btn btn-primary" href="<?php echo e(route("infos.edit", $info->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("infos-delete")): ?>
                                <confirm-delete
                                    :data-id="<?php echo e(json_encode($info->id)); ?>" 
                                    :data-title="<?php echo e(json_encode($info->title)); ?>" 
                                    :data-url="<?php echo e(json_encode('/infos/' . $info->id)); ?>" 
                                    data-redirect-url="/infos">
                                </confirm-delete>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/infos/index.blade.php ENDPATH**/ ?>