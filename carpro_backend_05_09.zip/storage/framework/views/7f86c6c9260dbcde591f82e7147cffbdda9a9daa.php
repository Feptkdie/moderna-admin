

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("users-create")): ?>
                <a href="<?php echo e(route("car-categories.create")); ?>" class="btn btn-success rounded-pill mb-3">Create category</a>
            <?php endif; ?>
            
            <h4 class="card-title">
                Car categories <small class="text-muted">(<?php echo e(count($categories)); ?>)</small>
            </h4>
            
            <table class="table table-striped">
                <tr>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-edit")): ?>
                                <a class="btn btn-primary" href="<?php echo e(route("car-categories.edit", $category->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-delete")): ?>
                                <confirm-delete
                                    :data-id="<?php echo e(json_encode($category->id)); ?>" 
                                    :data-title="<?php echo e(json_encode($category->name)); ?>" 
                                    :data-url="<?php echo e(json_encode('/car-categories/' . $category->id)); ?>" 
                                    data-redirect-url="/car-categories">
                                </confirm-delete>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCat1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="padding-left:25px;">--> <?php echo e($childCat1->name); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-edit")): ?>
                                    <a class="btn btn-primary" href="<?php echo e(route("car-categories.edit", $childCat1->id)); ?>">Edit</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-delete")): ?>
                                    <confirm-delete
                                        :data-id="<?php echo e(json_encode($childCat1->id)); ?>" 
                                        :data-title="<?php echo e(json_encode($childCat1->name)); ?>" 
                                        :data-url="<?php echo e(json_encode('/car-categories/' . $childCat1->id)); ?>" 
                                        data-redirect-url="/car-categories">
                                    </confirm-delete>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $childCat1->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCat2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="padding-left:55px;">--> <?php echo e($childCat2->name); ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-edit")): ?>
                                        <a class="btn btn-primary" href="<?php echo e(route("car-categories.edit", $childCat2->id)); ?>">Edit</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("car-categories-delete")): ?>
                                        <confirm-delete
                                            :data-id="<?php echo e(json_encode($childCat2->id)); ?>" 
                                            :data-title="<?php echo e(json_encode($childCat2->name)); ?>" 
                                            :data-url="<?php echo e(json_encode('/car-categories/' . $childCat2->id)); ?>" 
                                            data-redirect-url="/car-categories">
                                        </confirm-delete>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carpro_backend\resources\views/car_categories/index.blade.php ENDPATH**/ ?>