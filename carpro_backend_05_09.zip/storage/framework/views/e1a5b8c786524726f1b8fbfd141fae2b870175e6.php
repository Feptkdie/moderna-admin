
<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="/home">Home</a></li>
           <li class="breadcrumb-item"><a href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
           <li class="breadcrumb-item " aria-current="page">Permission edit</li>
        </ol>
    </nav>

    <h3><?php echo e($permission->name); ?></h3>
    
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route("permissions.update", $permission->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="<?php echo e($permission->name); ?>">
        </div>

        <div class="form-group">
            <label for="code">Description:</label>
            <input type="text" name="description" class="form-control" id="code" placeholder="products-create" value="<?php echo e($permission->description); ?>">
        </div>
        
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/permissions/edit.blade.php ENDPATH**/ ?>