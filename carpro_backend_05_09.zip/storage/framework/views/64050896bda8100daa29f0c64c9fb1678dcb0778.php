
<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="/home">Home</a></li>
           <li class="breadcrumb-item"><a href="<?php echo e(route("companies.index")); ?>">Companies</a></li>
           <li class="breadcrumb-item " aria-current="page">Company edit</li>
        </ol>
     </nav>

    <h3><?php echo e($company->name); ?></h3>
    
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route("companies.update", $company->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>

        <multi-select data-mode="edit" :data-selected-categories="<?php echo e(json_encode($company->categories->pluck("id"))); ?>" :data-categories="<?php echo e(json_encode($categories)); ?>"></multi-select>

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control" id="name" value="<?php echo e($company->name); ?>">
        </div>

        <div class="form-group">
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e($company->phone); ?>">
        </div>

        <div class="form-group">
            <label for="logo">Image:</label> 
            <input class="form-control-file border border-input-color bg-white p-1 rounded" id="logo" name="logo" type="file">
            <?php if(Storage::disk("s3")->exists(parse_url($company->logo)["path"])): ?> 
                <img src="<?php echo e($company->logo); ?>" class="img-fluid mt-3" style="max-width: 100px;"/>
            <?php endif; ?>
        </div>

        <company-additions :data-company="<?php echo e(json_encode($company)); ?>"></company-additions>

        <location-map data-name="<?php echo e($company->name); ?>" data-coord-x="<?php echo e($company->coord_x); ?>" data-coord-y="<?php echo e($company->coord_y); ?>"></location-map>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/companies/edit.blade.php ENDPATH**/ ?>