

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <a href="<?php echo e(route("permissions.create")); ?>" class="btn btn-success rounded-pill">Create permisison</a>

            <h4 class="card-title mt-3">
                Permissions <small class="text-muted">(0)</small>
            </h4>

            <table class="table">
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Group</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background-color: rgba(0,0,0, 0.05)">
                        <td colspan="4">Table: <?php echo e($groupName); ?></td>
                    </tr>
                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->description); ?></td>
                            <td><?php echo e($data->group_name); ?></td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(route("permissions.edit", $data->id)); ?>">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carpro_backend\resources\views/permissions/index.blade.php ENDPATH**/ ?>