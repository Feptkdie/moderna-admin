

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="card border-0 shadow-sm">
        
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("users-create")): ?>
                <a href="<?php echo e(route("cars.create")); ?>" class="btn btn-success rounded-pill mb-3">Машин нэмэх</a>
            <?php endif; ?>
            
            <h4 class="card-title">
                Машинууд <small class="text-muted">(<?php echo e(count($cars)); ?>)</small>
            </h4>
            <table class="table table-striped">
                <tr>
                    <th>Зураг</th>
                    <th>Нэр</th>
                    <th>Бүлэг</th>
                    <th>Үйлдвэрлэгч</th>
                    <th>Загвар</th>
                    <th>Орж ирсэн он</th>
                    <th>Үйлдвэрлэсэн он</th>
                    <th>Үнэ</th>
                    <th>Борлуулагч</th>
                    <th></th>
                </tr>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if(count($car->images) > 0): ?> 
                                <img src="<?php echo e($car->images[0]->url); ?>" class="img-fluid" style="max-width:100px;">
                                <p class="text-muted text-center"><?php echo e(count($car->images)); ?> зураг</p>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($car->name); ?></td>
                        <td>
                            <?php if(!empty($car->group->name)): ?>
                                <?php echo e($car->group->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!empty($car->mark->name)): ?>
                                <?php echo e($car->mark->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!empty($car->model->name)): ?>
                                <?php echo e($car->model->name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($car->import_year); ?> он, <?php echo e($car->import_month); ?> сар</td>
                        <td><?php echo e($car->made_in_year); ?></td>
                        <td><?php echo e(number_format($car->price, 0)); ?></td>
                        <td><?php echo e($car->seller); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("cars-list")): ?>
                                <a class="btn btn-info" href="<?php echo e(route("cars.show", $car->id)); ?>">Show</a>
                            <?php endif; ?> 
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("cars-edit")): ?>
                                <a class="btn btn-primary" href="<?php echo e(route("cars.edit", $car->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("cars-delete")): ?>
                                <confirm-delete
                                    :data-id="<?php echo e(json_encode($car->id)); ?>" 
                                    :data-title="<?php echo e(json_encode($car->name)); ?>" 
                                    :data-url="<?php echo e(json_encode('/cars/' . $car->id)); ?>" 
                                    data-redirect-url="/cars">
                                </confirm-delete>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/cars/index.blade.php ENDPATH**/ ?>