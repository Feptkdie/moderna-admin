
<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="/home">Home</a></li>
           <li class="breadcrumb-item"><a href="<?php echo e(route("users.index")); ?>">Users</a></li>
           <li class="breadcrumb-item " aria-current="page">User edit</li>
        </ol>
    </nav>

    <h3><?php echo e($user->name); ?></h3>
    
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route("users.update", $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="<?php echo e($user->name); ?>">
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" name="email" class="form-control" id="email" placeholder="email" value="<?php echo e($user->email); ?>">
        </div>

        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" class="form-control" id="password">
        </div>

        <div class="form-group">
            <label for="password2">Password confirm:</label>
            <input type="password" name="password_confirmation" class="form-control" id="password2">
        </div>
       
        <div class="form-group">
            <label for="roles">Roles:</label>
            <select name="role" class="form-control" id="roles">
                <option value="">-- Select --</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                        value="<?php echo e($role->id); ?>"
                        <?php echo e(in_array($role->id, $user->roles->pluck("id")->toArray()) ? "selected" : ""); ?>

                    >
                        <?php echo e($role->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>Permissions</label>
            <ul>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($groupName); ?>

                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" 
                                    name="permissions[]" 
                                    class="custom-control-input" 
                                    id="customCheck<?php echo e($perm->id); ?>" 
                                    value="<?php echo e($perm->id); ?>"
                                    <?php echo e(in_array($perm->id, $user->permissions->pluck("id")->toArray()) ? "checked" : ""); ?>

                                >
                                <label class="custom-control-label" for="customCheck<?php echo e($perm->id); ?>">
                                    <?php echo e($perm->description); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/users/edit.blade.php ENDPATH**/ ?>