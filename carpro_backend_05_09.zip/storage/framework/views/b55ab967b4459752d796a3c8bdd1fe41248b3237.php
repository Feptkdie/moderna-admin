

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("users-create")): ?>
                <a href="<?php echo e(route("company-categories.create")); ?>" class="btn btn-success rounded-pill mb-3">Create category</a>
            <?php endif; ?>
            
            <h4 class="card-title">
                Company categories <small class="text-muted">(<?php echo e(count($categories)); ?>)</small>
            </h4>
            
            <table class="table table-striped">
                <tr>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <?php if(!empty($category->image)): ?>
                                <img src="<?php echo e($category->image); ?>" class="img-fluid" style="max-width: 100px;" />
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($category->created_at); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("company-categories-list")): ?>
                                <a class="btn btn-info" href="<?php echo e(route("company-categories.show", $category->id)); ?>">Show</a>
                            <?php endif; ?> 
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("company-categories-edit")): ?>
                                <a class="btn btn-primary" href="<?php echo e(route("company-categories.edit", $category->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("company-categories-delete")): ?>
                                <confirm-delete
                                    :data-id="<?php echo e(json_encode($category->id)); ?>" 
                                    :data-title="<?php echo e(json_encode($category->name)); ?>" 
                                    :data-url="<?php echo e(json_encode('/company-categories/' . $category->id)); ?>" 
                                    data-redirect-url="/company-categories">
                                </confirm-delete>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/company_categories/index.blade.php ENDPATH**/ ?>