
<?php $__env->startSection('content'); ?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
           <li class="breadcrumb-item"><a href="/home">Home</a></li>
           <li class="breadcrumb-item"><a href="<?php echo e(route("infos.index")); ?>">Infos</a></li>
           <li class="breadcrumb-item " aria-current="page">Info create</li>
        </ol>
     </nav>

    <h3>Create Info</h3>
    
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    

    <form action="<?php echo e(route("infos.store")); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <multi-select data-mode="add" :data-categories="<?php echo e(json_encode($categories)); ?>"></multi-select>
        
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" name="title" class="form-control" id="title">
        </div>

        <div class="form-group">
            <label for="subtitle">Sub title:</label>
            <textarea name="subtitle" class="form-control" id="subtitle" rows="3"></textarea>
        </div>

        <info-file-select data-mode="add"></info-file-select>

        <div class="form-group">
            <label for="content">Content:</label>
            <textarea id="content" name="content" class="form-control"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("javascript"); ?>
<script src="https://cdn.tiny.cloud/1/lcidoke8z58yahye4qdipgpqiadzheladm0c6pbea3gt42pc/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    tinymce.init({
        selector: '#content',
        image_class_list: [
            {
                title: 'img-responsive', 
                value: 'img-responsive'
            },
        ],
        height: 500,
        setup: function (editor) {
            editor.on('init change', function () {
                editor.save();
            });
        },
        plugins: [
            "advlist autolink lists link image charmap print preview anchor",
            "searchreplace visualblocks code fullscreen",
            "insertdatetime media table contextmenu paste imagetools"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
        image_advtab: true,
        image_title: true,
        // automatic_uploads: true,
        // images_upload_url: '/upload',
        file_picker_types: 'image',
        file_picker_callback: function(cb, value, meta) {
            var input = document.createElement('input');
            input.setAttribute('type', 'file');
            input.setAttribute('accept', 'image/*');
            input.onchange = function() {
                var file = this.files[0];

                var reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = function () {
                    var id = 'blobid' + (new Date()).getTime();
                    var blobCache =  tinymce.activeEditor.editorUpload.blobCache;
                    var base64 = reader.result.split(',')[1];
                    var blobInfo = blobCache.create(id, file, base64);
                    blobCache.add(blobInfo);
                    cb(blobInfo.blobUri(), { title: file.name });
                };
            };
            input.click();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bombi\Desktop\carpro-web\resources\views/infos/create.blade.php ENDPATH**/ ?>