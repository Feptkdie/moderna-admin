

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo $__env->make("flash_message", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("users-create")): ?>
                <a href="<?php echo e(route("companies.create")); ?>" class="btn btn-success rounded-pill mb-3">Create company</a>
            <?php endif; ?>
            
            <h4 class="card-title">
                Companies <small class="text-muted">(<?php echo e(count($companies)); ?>)</small>
            </h4>
            <table class="table table-striped">
                <tr>
                    <th>Name</th>
                    <th>Categories</th>
                    <th>Logo</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($company->name); ?></td>
                        <td>
                            <?php $__currentLoopData = $company->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h5><span class="badge badge-secondary"><?php echo e($category->name); ?></span></h5>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if(!empty($company->logo)): ?>
                                <img src="<?php echo e($company->logo); ?>" class="img-fluid" style="max-width: 100px;" />
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($company->created_at); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("companies-list")): ?>
                                <a class="btn btn-info" href="<?php echo e(route("companies.show", $company->id)); ?>">Show</a>
                            <?php endif; ?> 
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("companies-edit")): ?>
                                <a class="btn btn-primary" href="<?php echo e(route("companies.edit", $company->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("companies-delete")): ?>
                                <confirm-delete
                                    :data-id="<?php echo e(json_encode($company->id)); ?>" 
                                    :data-title="<?php echo e(json_encode($company->name)); ?>" 
                                    :data-url="<?php echo e(json_encode('/companies/' . $company->id)); ?>" 
                                    data-redirect-url="/companies">
                                </confirm-delete>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carpro_backend\resources\views/companies/index.blade.php ENDPATH**/ ?>