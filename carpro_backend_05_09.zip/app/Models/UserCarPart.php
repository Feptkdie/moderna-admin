<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCarPart extends Model
{
    use HasFactory;

    protected $table = "user_car_parts";
    
}
