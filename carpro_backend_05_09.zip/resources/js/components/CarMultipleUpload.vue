<template>
  <div class="car-multiple-upload mt-3 mb-3">
    <button type="button" class="btn btn-success rounded mb-3" @click="addFile">Зураг нэмэх</button>
    <ul class="list-group" >
      <li class="list-group-item" v-for="file in files" :key="file.id">
        <input type="file" name="files[]" accept="image/*" @change="previewImage" :data-id="file.id">
        <img :src="file.base64Url" v-if="file.base64Url" class="img-fluid" style="max-width:100px;">
        <button type="button" class="btn btn-sm btn-danger ml-2" @click="remove(file)">Устгах</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count: 0,
      files: []
    }
  },
  methods: {
    addFile() {
      this.count = this.count + 1;
      this.files.push({
        id: this.count,
        base64Url: ""
      });
    },
    remove(file) {
      const index = this.files.indexOf(file);
      this.files.splice(index, 1);
    },
    previewImage(event) {
      var input = event.target;
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = (e) => {
          const file = this.files.find(file => file.id == input.dataset.id);
          file.base64Url = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
      }
    }
  }
}
</script>